import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import http from "node:http";
import { extractAdminState, patchAppSource } from "./core.mjs";

const root = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(root, "public");
loadDotEnv(path.join(root, ".env"));

const config = {
  port: Number(process.env.PORT || 8787),
  repo: process.env.MIRPANEL_GITHUB_REPO || "mircavad09/mirpanel",
  branch: process.env.MIRPANEL_GITHUB_BRANCH || "main",
  token: process.env.MIRPANEL_GITHUB_TOKEN || "",
  adminKey: process.env.MIRPANEL_ADMIN_KEY || "",
  allowedOrigin: process.env.MIRPANEL_ALLOWED_ORIGIN || ""
};

function loadDotEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const index = trimmed.indexOf("=");
    if (index < 1) continue;
    const key = trimmed.slice(0, index).trim();
    const value = trimmed.slice(index + 1).trim().replace(/^['"]|['"]$/g, "");
    if (!process.env[key]) process.env[key] = value;
  }
}

function json(response, status, body, extraHeaders = {}) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...extraHeaders
  });
  response.end(JSON.stringify(body));
}

function sameSecret(actual, expected) {
  if (!actual || !expected) return false;
  const left = Buffer.from(actual);
  const right = Buffer.from(expected);
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function apiHeaders() {
  return {
    Accept: "application/vnd.github+json",
    Authorization: `Bearer ${config.token}`,
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "mirpanel-admin"
  };
}

async function github(pathname, options = {}) {
  if (!config.token) throw new Error("MIRPANEL_GITHUB_TOKEN teyin edilmeyib.");
  const response = await fetch(`https://api.github.com${pathname}`, {
    ...options,
    headers: { ...apiHeaders(), ...(options.headers || {}) }
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.message || `GitHub xetasi: ${response.status}`);
    error.status = response.status;
    throw error;
  }
  return payload;
}

function decodeContent(content) {
  return Buffer.from(content.replace(/\n/g, ""), "base64").toString("utf8");
}

async function getAppFile() {
  const ref = encodeURIComponent(config.branch);
  const file = await github(`/repos/${config.repo}/contents/app.js?ref=${ref}`);
  return { sha: file.sha, source: decodeContent(file.content) };
}

async function readBody(request, limit = 1_500_000) {
  let size = 0;
  const chunks = [];
  for await (const chunk of request) {
    size += chunk.length;
    if (size > limit) throw new Error("Gonderilen melumat cox boyukdur.");
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
}

function isAuthorized(request) {
  return sameSecret(request.headers["x-admin-key"], config.adminKey);
}

async function handleApi(request, response) {
  if (!config.adminKey) {
    return json(response, 500, { error: "MIRPANEL_ADMIN_KEY teyin edilmeyib." });
  }
  if (!isAuthorized(request)) {
    return json(response, 401, { error: "Admin acari yanlisdir." });
  }

  if (request.method === "GET" && request.url === "/api/admin/state") {
    const file = await getAppFile();
    return json(response, 200, {
      sha: file.sha,
      data: extractAdminState(file.source),
      loadedAt: new Date().toISOString()
    });
  }

  if (request.method === "POST" && request.url === "/api/admin/save") {
    const body = await readBody(request);
    if (!body.baseSha || !body.data) return json(response, 400, { error: "baseSha ve data teleb olunur." });
    const current = await getAppFile();
    if (current.sha !== body.baseSha) {
      return json(response, 409, {
        error: "app.js GitHub-da basqa yerde deyisib. Sehifeni yenile ve deyisiklikleri yeniden et.",
        currentSha: current.sha
      });
    }
    const patched = patchAppSource(current.source, body.data);
    const result = await github(`/repos/${config.repo}/contents/app.js`, {
      method: "PUT",
      body: JSON.stringify({
        message: "Update Mirpanel content from admin panel",
        content: Buffer.from(patched, "utf8").toString("base64"),
        sha: current.sha,
        branch: config.branch
      })
    });
    return json(response, 200, {
      sha: result.content.sha,
      commitSha: result.commit.sha,
      committedAt: new Date().toISOString()
    });
  }

  return json(response, 404, { error: "Endpoint tapilmadi." });
}

const mime = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml"
};

function serveStatic(request, response) {
  const requested = request.url === "/" ? "/admin.html" : request.url.split("?")[0];
  const file = path.normalize(path.join(publicDir, requested));
  if (!file.startsWith(publicDir)) return json(response, 403, { error: "Forbidden" });
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) return json(response, 404, { error: "Fayl tapilmadi." });
  response.writeHead(200, {
    "Content-Type": mime[path.extname(file)] || "application/octet-stream",
    "Cache-Control": "no-store"
  });
  fs.createReadStream(file).pipe(response);
}

export const server = http.createServer(async (request, response) => {
  try {
    if (request.url.startsWith("/api/")) return await handleApi(request, response);
    return serveStatic(request, response);
  } catch (error) {
    console.error(error);
    return json(response, error.status || 500, { error: error.message || "Server xetasi." });
  }
});

server.listen(config.port, () => {
  console.log(`Mirpanel admin: http://localhost:${config.port}`);
});
