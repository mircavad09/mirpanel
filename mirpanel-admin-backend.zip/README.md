# Mirpanel Admin Backend

Bu qovluq Mirpanel statik saytı üçün təhlükəsiz admin paneldir.

## Qurulum

1. `.env.example` faylını `.env` adı ilə kopyala.
2. `.env` daxilində GitHub token və şəxsi admin açarını yaz.
3. Serveri başlat:

```powershell
npm start
```

4. Brauzerdə aç:

```text
http://localhost:8787
```

## Environment variables

```text
PORT=8787
MIRPANEL_GITHUB_REPO=mircavad09/mirpanel
MIRPANEL_GITHUB_BRANCH=main
MIRPANEL_GITHUB_TOKEN=github_fine_grained_token
MIRPANEL_ADMIN_KEY=choose_a_long_private_admin_key
```

GitHub fine-grained token üçün yalnız `mircavad09/mirpanel` repository-sini seç və
`Contents: Read and write` icazəsi ver. Tokeni frontend fayllarına yazma və `.env`
faylını GitHub-a commit etmə.

## İş prinsipi

- Admin panel GitHub tokeni görmür.
- Brauzer serverə yalnız `MIRPANEL_ADMIN_KEY` ilə sorğu göndərir.
- Server `app.js` faylını GitHub API-dən oxuyur.
- `Saxla` düyməsi serverdə `app.js` faylını yeniləyir və commit edir.
- GitHub-dakı cari SHA köhnə SHA ilə uyğun gəlmirsə server `409 Conflict` qaytarır.
- Məhsul, qiymət, şəkil, flow, stok, aktivlik, kateqoriya, "Məhsul haqqında" və
  "İstifadə qaydaları" paneldən idarə olunur.

