const $ = (id) => document.getElementById(id);
const state = { data: null, baseSha: "", selectedId: "", dirty: false, modalAction: null };
const flows = [["whatsapp","Birbaşa WhatsApp"],["name_code_4","Ad + 4 rəqəm kod"],["name_code_5","Ad + 5 rəqəm kod"],["email","Gmail form"],["spotify","Gmail + şifrə"],["out_of_stock","Stokda yoxdur"]];
const imageUrl = (path) => /^https?:/i.test(path || "") ? path : `https://mirpanel.com/${path || "assets/your.png"}`;
const escapeHtml = (value) => String(value ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;");
const slug = (value) => String(value || "").trim().toLowerCase().replaceAll("ə","e").replaceAll("ı","i").replaceAll("ö","o").replaceAll("ü","u").replaceAll("ş","s").replaceAll("ç","c").replaceAll("ğ","g").replace(/[^a-z0-9_]+/g,"_").replace(/_+/g,"_").replace(/^_|_$/g,"");

function adminKey(){return sessionStorage.getItem("mirpanel_admin_key") || ""}
async function api(path, options={}){
  const response=await fetch(path,{...options,headers:{"Content-Type":"application/json","X-Admin-Key":adminKey(),...(options.headers||{})}});
  const payload=await response.json().catch(()=>({}));
  if(!response.ok){const error=new Error(payload.error||`Server xətası: ${response.status}`);error.status=response.status;throw error}
  return payload;
}
function setLoading(on,text="Yüklənir..."){$("loading").classList.toggle("hidden",!on);$("loadingText").textContent=text;$("saveBtn").disabled=on}
function toast(text,type="good"){const el=document.createElement("div");el.className=`toast ${type}`;el.textContent=text;$("toasts").appendChild(el);setTimeout(()=>el.remove(),4200)}
function markDirty(){state.dirty=true;renderStats()}
function selected(){return state.data?.products.find((p)=>p.id===state.selectedId)||null}
function price(product){const values=(product.plans||[]).map((p)=>Number(p.price)).filter((p)=>p>0);return values.length?Math.min(...values).toFixed(2):"0.00"}

async function loadState(){
  setLoading(true,"GitHub məlumatları oxunur...");
  try{
    const payload=await api("/api/admin/state");
    state.data=payload.data;state.baseSha=payload.sha;state.selectedId=state.data.products[0]?.id||"";state.dirty=false;
    $("loginScreen").classList.add("hidden");$("app").classList.remove("hidden");
    $("commitInfo").textContent=`Yükləndi: ${new Date(payload.loadedAt).toLocaleString("az-AZ")} / ${payload.sha.slice(0,7)}`;
    renderAll();toast("Məlumatlar GitHub-dan yükləndi.");
  }catch(error){
    if(error.status===401){sessionStorage.removeItem("mirpanel_admin_key");$("loginScreen").classList.remove("hidden");$("app").classList.add("hidden");$("loginError").textContent=error.message}
    else toast(error.message,"bad");
  }finally{setLoading(false)}
}
async function saveState(){
  if(!state.data||!state.dirty)return toast("Saxlanacaq dəyişiklik yoxdur.","bad");
  setLoading(true,"Dəyişikliklər GitHub-a yazılır...");
  try{
    const payload=await api("/api/admin/save",{method:"POST",body:JSON.stringify({baseSha:state.baseSha,data:state.data})});
    state.baseSha=payload.sha;state.dirty=false;renderStats();
    $("commitInfo").textContent=`Commit: ${payload.commitSha.slice(0,7)} / ${new Date(payload.committedAt).toLocaleString("az-AZ")}`;
    toast("Dəyişikliklər GitHub-a yazıldı.");
  }catch(error){
    toast(error.status===409?"Conflict: GitHub-da app.js dəyişib. Yenilə düyməsini bas.":error.message,"bad");
  }finally{setLoading(false)}
}
function renderAll(){renderStats();renderFilters();renderProducts();renderProductForm();renderCategories();renderSettings()}
function renderStats(){if(!state.data)return;$("statProducts").textContent=state.data.products.length;$("statActive").textContent=state.data.products.filter((p)=>p.active!==false).length;$("statCategories").textContent=state.data.categories.length;$("statDirty").textContent=state.dirty?"Var":"Yoxdur"}
function renderFilters(){
  const current=$("categoryFilter").value||"all";
  $("categoryFilter").innerHTML=`<option value="all">Bütün kateqoriyalar</option>${state.data.categories.filter((c)=>c.key!=="all").map((c)=>`<option value="${escapeHtml(c.key)}">${escapeHtml(c.name)}</option>`).join("")}`;
  $("categoryFilter").value=[...$("categoryFilter").options].some((o)=>o.value===current)?current:"all";
}
function renderProducts(){
  const query=$("searchInput").value.trim().toLowerCase(),category=$("categoryFilter").value,status=$("statusFilter").value;
  const list=state.data.products.slice().sort((a,b)=>(a.order??999)-(b.order??999)).filter((p)=>{
    const text=[p.title,p.id,p.badge,p.variant].join(" ").toLowerCase();
    return(!query||text.includes(query))&&(category==="all"||p.category===category)&&(status==="all"||(status==="active"&&p.active!==false)||(status==="inactive"&&p.active===false)||(status==="soldout"&&p.soldOut));
  });
  $("productList").innerHTML=list.length?list.map((p)=>`<button class="productItem ${p.id===state.selectedId?"active":""}" data-id="${escapeHtml(p.id)}"><img src="${escapeHtml(imageUrl(p.image))}" alt=""><div><strong>${escapeHtml(p.title)}</strong><span>${escapeHtml(p.category)} / ${p.active===false?"Deaktiv":"Aktiv"}</span></div><b class="price">${price(p)} ${escapeHtml(p.currency)}</b></button>`).join(""):`<div class="emptyState">Nəticə tapılmadı.</div>`;
  document.querySelectorAll(".productItem").forEach((button)=>button.onclick=()=>{state.selectedId=button.dataset.id;renderProducts();renderProductForm()});
}
function options(items,value){return items.map(([key,label])=>`<option value="${escapeHtml(key)}" ${key===value?"selected":""}>${escapeHtml(label)}</option>`).join("")}
function renderProductForm(){
  const p=selected();$("productEmpty").classList.toggle("hidden",!!p);$("productForm").classList.toggle("hidden",!p);if(!p)return;
  $("previewImage").src=imageUrl(p.image);$("previewTitle").textContent=p.title;$("previewMeta").textContent=`${p.id} / ${p.category}`;
  $("productActive").checked=p.active!==false;$("productOrder").value=p.order??"";$("productId").value=p.id;$("productTitle").value=p.title;$("productVariant").value=p.variant;$("productCategory").innerHTML=options(state.data.categories.map((c)=>[c.key,c.name]),p.category);$("productFlow").innerHTML=options(flows,p.flow);$("productImage").value=p.image;$("productBadge").value=p.badge;$("productCurrency").value=p.currency;$("productSoldOut").value=String(!!p.soldOut);$("productDesc").value=p.desc;$("productNote").value=p.note;$("aboutHtml").value=state.data.content[p.id]?.aboutHtml||"";$("rulesHtml").value=state.data.content[p.id]?.rulesHtml||"";
  renderPlans(p);
}
function bind(id,update){$(id).addEventListener("input",()=>{const p=selected();if(!p)return;update(p,$(id));markDirty();renderProducts()})}
bind("productActive",(p,e)=>p.active=e.checked);bind("productOrder",(p,e)=>p.order=e.value===""?null:Number(e.value));bind("productId",(p,e)=>{const old=p.id;p.id=slug(e.value);state.selectedId=p.id;state.data.content[p.id]=state.data.content[old]||{};if(old!==p.id)delete state.data.content[old]});bind("productTitle",(p,e)=>{p.title=e.value;$("previewTitle").textContent=p.title});bind("productVariant",(p,e)=>p.variant=e.value);bind("productCategory",(p,e)=>{p.category=e.value;$("previewMeta").textContent=`${p.id} / ${p.category}`});bind("productFlow",(p,e)=>p.flow=e.value);bind("productImage",(p,e)=>{p.image=e.value;$("previewImage").src=imageUrl(p.image)});bind("productBadge",(p,e)=>p.badge=e.value);bind("productCurrency",(p,e)=>p.currency=e.value);bind("productSoldOut",(p,e)=>p.soldOut=e.value==="true");bind("productDesc",(p,e)=>p.desc=e.value);bind("productNote",(p,e)=>p.note=e.value);bind("aboutHtml",(p,e)=>(state.data.content[p.id]??={}).aboutHtml=e.value);bind("rulesHtml",(p,e)=>(state.data.content[p.id]??={}).rulesHtml=e.value);
function renderPlans(p){$("plans").innerHTML=(p.plans||[]).map((plan,index)=>`<div class="planRow"><input data-plan="${index}" data-field="label" placeholder="Label" value="${escapeHtml(plan.label||"")}"><input data-plan="${index}" data-field="months" type="number" placeholder="Ay" value="${escapeHtml(plan.months??"")}"><input data-plan="${index}" data-field="price" type="number" step="0.01" placeholder="Qiymət" value="${escapeHtml(plan.price??"")}"><button class="iconBtn removePlan" data-plan="${index}" type="button">X</button></div>`).join("");document.querySelectorAll("[data-field]").forEach((input)=>input.oninput=()=>{const plan=p.plans[Number(input.dataset.plan)];plan[input.dataset.field]=input.dataset.field==="label"?input.value:Number(input.value);markDirty();renderProducts()});document.querySelectorAll(".removePlan").forEach((button)=>button.onclick=()=>{p.plans.splice(Number(button.dataset.plan),1);markDirty();renderPlans(p);renderProducts()})}
function renderCategories(){$("categoriesBody").innerHTML=state.data.categories.map((c,index)=>`<tr><td>${index+1}</td><td><input data-cat="${index}" data-cat-field="key" value="${escapeHtml(c.key)}"></td><td><input data-cat="${index}" data-cat-field="name" value="${escapeHtml(c.name)}"></td><td>${state.data.products.filter((p)=>p.category===c.key).length}</td><td>${c.key==="all"?"":`<button class="btn danger deleteCat" data-cat="${index}">Sil</button>`}</td></tr>`).join("");document.querySelectorAll("[data-cat-field]").forEach((input)=>input.oninput=()=>{const cat=state.data.categories[Number(input.dataset.cat)],old=cat.key;cat[input.dataset.catField]=input.dataset.catField==="key"?slug(input.value):input.value;if(old!==cat.key)state.data.products.forEach((p)=>{if(p.category===old)p.category=cat.key});markDirty();renderFilters()});document.querySelectorAll(".deleteCat").forEach((button)=>button.onclick=()=>confirmDeleteCategory(Number(button.dataset.cat)))}
function renderSettings(){$("settingBrand").value=state.data.brand;$("settingPhone").value=state.data.phone_wa}
$("settingBrand").oninput=()=>{state.data.brand=$("settingBrand").value;markDirty()};$("settingPhone").oninput=()=>{state.data.phone_wa=$("settingPhone").value;markDirty()};
function showView(view){["products","categories","settings"].forEach((name)=>$(`${name}View`).classList.toggle("hidden",name!==view));document.querySelectorAll(".navBtn[data-view]").forEach((btn)=>btn.classList.toggle("active",btn.dataset.view===view));$("crumb").textContent={products:"Məhsullar",categories:"Kateqoriyalar",settings:"Ayarlar"}[view]}
function openModal(title,body,confirmText,action){$("modalTitle").textContent=title;$("modalBody").innerHTML=body;$("modalConfirm").textContent=confirmText;state.modalAction=action;$("modal").classList.remove("hidden")}
function closeModal(){$("modal").classList.add("hidden");state.modalAction=null}
function confirmDeleteCategory(index){const c=state.data.categories[index];openModal("Kateqoriyanı sil",`<p>${escapeHtml(c.name)} silinsin? Məhsullar Hamısı kateqoriyasına keçiriləcək.</p>`,"Sil",()=>{state.data.products.forEach((p)=>{if(p.category===c.key)p.category="all"});state.data.categories.splice(index,1);markDirty();renderAll();closeModal()})}
$("addProductBtn").onclick=()=>openModal("Yeni məhsul",`<div class="modalGrid"><label>Ad<input id="newProductTitle"></label><label>ID<input id="newProductId"></label><label>Şəkil yolu<input id="newProductImage" value="assets/your.png"></label></div>`,"Əlavə et",()=>{const title=$("newProductTitle").value.trim(),id=slug($("newProductId").value||title);if(!title||!id)return toast("Ad və ID tələb olunur.","bad");if(state.data.products.some((p)=>p.id===id))return toast("Bu ID artıq var.","bad");state.data.products.push({id,order:state.data.products.length,category:"all",image:$("newProductImage").value,currency:"₼",title,variant:"",badge:"Premium",desc:"",note:"",flow:"whatsapp",soldOut:false,active:true,plans:[{months:1,price:0}]});state.data.content[id]={aboutHtml:"",rulesHtml:""};state.selectedId=id;markDirty();renderAll();closeModal()});
$("deleteProductBtn").onclick=()=>{const p=selected();if(!p)return;openModal("Məhsulu sil",`<p>${escapeHtml(p.title)} silinsin?</p>`,"Sil",()=>{state.data.products=state.data.products.filter((x)=>x!==p);delete state.data.content[p.id];state.selectedId=state.data.products[0]?.id||"";markDirty();renderAll();closeModal()})};
$("addCategoryBtn").onclick=()=>openModal("Yeni kateqoriya",`<div class="modalGrid"><label>Ad<input id="newCategoryName"></label><label>Key<input id="newCategoryKey"></label></div>`,"Əlavə et",()=>{const name=$("newCategoryName").value.trim(),key=slug($("newCategoryKey").value||name);if(!name||!key)return toast("Ad və key tələb olunur.","bad");if(state.data.categories.some((c)=>c.key===key))return toast("Bu key artıq var.","bad");state.data.categories.push({key,name});markDirty();renderAll();closeModal()});
$("addPlanBtn").onclick=()=>{const p=selected();p.plans.push({label:"1 aylıq",months:1,price:0});markDirty();renderPlans(p)};
$("refreshBtn").onclick=()=>{if(state.dirty&&!confirm("Saxlanılmamış dəyişikliklər silinəcək. Davam et?"))return;loadState()};$("saveBtn").onclick=saveState;$("searchInput").oninput=renderProducts;$("categoryFilter").onchange=renderProducts;$("statusFilter").onchange=renderProducts;$("modalClose").onclick=closeModal;$("modalCancel").onclick=closeModal;$("modalConfirm").onclick=()=>state.modalAction?.();$("modal").onclick=(e)=>{if(e.target===$("modal"))closeModal()};document.querySelectorAll(".navBtn[data-view]").forEach((btn)=>btn.onclick=()=>showView(btn.dataset.view));$("logoutBtn").onclick=()=>{sessionStorage.removeItem("mirpanel_admin_key");location.reload()};
$("loginForm").onsubmit=(event)=>{event.preventDefault();sessionStorage.setItem("mirpanel_admin_key",$("adminKey").value);$("loginError").textContent="";loadState()};
if(adminKey())loadState();
